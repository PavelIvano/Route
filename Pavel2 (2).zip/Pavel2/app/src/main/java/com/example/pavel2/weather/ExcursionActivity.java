package com.example.pavel2.weather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.pavel2.R;

public class ExcursionActivity extends AppCompatActivity {

    TextView titleTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excursion2);
        Intent intent = getIntent();


        titleTV = findViewById(R.id.titleTV);


        int position = getIntent().getIntExtra("position", -1);
        Excursion excursion = MainActivity.excursions.get(position);
        System.out.println(excursion);
    }
}