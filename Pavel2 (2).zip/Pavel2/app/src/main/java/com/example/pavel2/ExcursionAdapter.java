package com.example.pavel2;

import android.content.Context;
import android.widget.ArrayAdapter;

import com.example.pavel2.weather.Excursion;

public class ExcursionAdapter extends ArrayAdapter<Excursion> {
    public ExcursionAdapter(Context context, Excursion[] arr) {
        super(context, R.layout.adapter_item, arr);
    }
}
