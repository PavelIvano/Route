package com.example.pavel2;

public class TV implements Speakable {
    public void speak() {
        System.out.println("Спокойной ночи малыши");
    }
}
