package com.example.pavel2;

public class NPC {
    static int a = 6;
    static int b = 7;

    public static void main(String[] args) {
        if (a == b) {
            System.out.println("EQ");
        } else {
            if (a != b) {
                System.out.println("NEQ");
            }
        }
    }

}
