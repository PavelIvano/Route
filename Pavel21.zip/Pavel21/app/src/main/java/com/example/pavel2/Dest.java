package com.example.pavel2;

public class Dest {
    public String street;
    public int homeNumber;
    public int roomNumber;

}
