package com.example.pavel2.module4;

public class FirstDigitComparator {
}
