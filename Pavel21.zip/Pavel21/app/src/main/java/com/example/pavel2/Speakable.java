package com.example.pavel2;

public interface Speakable {
    public void speak ();
}
