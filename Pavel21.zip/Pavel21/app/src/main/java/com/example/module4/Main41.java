package com.example.pavel2.module4;

import java.util.Arrays;

public class Main41 {
    public static void main(String[] args) {
        Integer[] b = {21,12,76,51,47};
        Arrays.sort(b);
        System.out.println(Arrays.toString(b));
    }

}

